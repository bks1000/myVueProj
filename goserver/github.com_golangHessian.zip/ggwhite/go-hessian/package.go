package hessian

// Package pojo class name, ex: lab.ggw.demo.User
type Package string
