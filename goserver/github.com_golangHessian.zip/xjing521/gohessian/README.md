# gohessian

gohessian implements  Hessian   Protocol by golang
